<div align="center">
  <img src="https://capsule-render.vercel.app/api?type=speech&height=200&color=gradient&text=WE'LL%20COME%20🥳&animation=blinking&fontAlign=36&fontAlignY=36&descAlign=62&reversal=false&textBg=false" width="100%">
</div>

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=70&pause=500&color=8A2BE2&center=true&width=1150&height=200&lines=PLEASE+FORK+STAR+BOT+REPO" alt="Typing SVG" /></a>
  </div>
<a><img src='https://i.ibb.co/mfvM5mL/1000825221.jpg'/></a>

<p align="center">
  <a href="https://github.com/MRSHYAM-MD42"><img title="Developer" src="https://img.shields.io/badge/Author-SHYAM-MD%20MD-FF00FF.svg?style=big-square&logo=github" /></a>
</p>

<div align="center">

<h1 align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=30&duration=6000&color=00FF00&background=000000&center=true&vCenter=true&width=600&lines=⚡+SHYAM-MD+MD+BETTER+OPTION;🔥+THE+MOST+POWERFUL+WHATSAPP+BOT;💻+DEVELOPER+BY+MR+SHYAM-MD42;🚀+SHYAM-MD+SOLUTIONS;🌈+FAST+⚡+SECURE+🔒+RELIABLE+✅" alt="Typing Animation">
</h1>
  
[![WhatsApp Channel](https://img.shields.io/badge/Join-WhatsApp%20Channel-9ACD32?style=big-square&logo=whatsapp)](https://chat.whatsapp.com/IOEbmfzOD6d9TCjdX5Fi3B?mode=wwt)
</div>

---------


<p align="center">
<a href="https://github.com/Dexsam07/SHYAM-MD-V2"><img title="PUBLIC-BOT" src="https://img.shields.io/static/v1?label=Language&message=English&style=square&color=darkpink"></a> &nbsp;
  <img src="https://komarev.com/ghpvc/?username=SHYAM-MD&label=VIEWS&style=square&color=blue" />
</p>
</p> 

<p align="center">
  <a href="https://github.com/Dexsam07/SHYAM-MD-V2"><img title="Release" src="https://img.shields.io/badge/Release-beta%20v5-cyan.svg?style=for-the-badge&logo=aqua" /></a>
</p>


***BOT FEATURE ⤵️***

| Menu ⁠➜ | Status Save + Send | Group | ChatBot | Downloading | Antidelete | Ai | Viewonce | Fun | Status Reply | Status Reacts | HeartReacts | Autoreacts | Call Rejecter 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Work ➜ |✅|✅|✅|✅|✅|✅|✅|✅|✅|✅|✅|✅|✅|

  
<a
href="https://github.com/Dexsam07/SHYAM-MD-V2/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>

 [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=monospace-ExtraBold&color=blue&lines=𝗙𝗢𝗥𝗞+𝗔𝗡𝗗+𝗦𝗧𝗔𝗥+⭐+𝗥𝗘𝗣𝗢)](https://git.io/typing-svg)
 <p align="lift">
 <a href="https://github.com/Dexsam07/SHYAM-MD-V2/fork"><img title="SHYAM-MD" src="https://img.shields.io/badge/FORK-SHYAM-MD MD-h?color=008000&style=for-the-badge&logo=github"></a>

  -------------
  
<a href='https://solar-linnell-SHYAM-MDsobxmd-409a0aff.koyeb.app/' target="_blank">
    <img src='https://img.shields.io/badge/PAIR_CODE-008080?style=for-the-badge&logo=matrix&logoColor=white&labelColor=000000'/>
  </a></br>
  
-------------

  <a href='https://teenage-esmeralda-sk66-485109a3.koyeb.app/' target="_blank">
    <img src='https://img.shields.io/badge/PAIR_CODE-FF8C00?style=for-the-badge&logo=matrix&logoColor=white&labelColor=000000'/>
  </a></br>

-------------

<a href="https://SHYAM-MD.lovestoblog.com/">
  <img 
    title="DEPLOY-NOW" 
    src="https://img.shields.io/badge/DEPLOY--NOW-Click%20to%20deploy-9400D3?style=for-the-badge&logo=vercel&logoColor=blue"
    width="500" 
    height="30.35"
    alt="Deploy with Vercel"
  />
</a>

-------------

**_✠ FREE DEPLOYMENT OF SHYAM-MD MD GITHUB WORKFLOW CODE ✠_**

```
name: Node.js CI

on:
  push:
    branches:
      - main
  pull_request:
    branches:
      - main

jobs:
  build:

    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [20.x]

    steps:
    - name: Checkout repository
      uses: actions/checkout@v3

    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}

    - name: Install dependencies
      run: npm install

    - name: Start application
      run: npm start
```

-------

<p align="center">
  <img src="https://i.imgur.com/LyHic3i.gif" alt="divider"/>
</p>


> 🔔 Stay Connected For Updates Feature Drops And Tutorials!

- ▶️ **YouTube SHYAM-MD**  
  [![Subscribe YouTube](https://img.shields.io/badge/Subscribe-YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://youtube.com/@mrSHYAM-MD282?si=ZVANSbKM0yajAbl_)

<p align="center">
  <img src="https://i.imgur.com/LyHic3i.gif" alt="footer divider"/>
</p>

## ⚠️ _WARNING !_

<div style="background-color: #000000; border-left: 5px solid #ff00ff; padding: 10px; border-radius: 0 15px 15px 0; box-shadow: 0 0 15px #ff00ff;">
  <h3 style="color: #00ffff; font-family: 'Orbitron', sans-serif;">DISCLAIMER</h3>
  <p style="color: #ffffff;">This Bot Is Not Affiliated With WhatsApp Inc. Use At Your Own Risk Misuse May Result In Account Bans</p>
</div>

## 🗃️ _PROJECT ARCHITECTS_
<div align="center">
  <!-- Glowing Header -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>
  <a href="https://github.com/Dexsam07/SHYAM-MD-V2">
    <img src="https://github-readme-stats.vercel.app/api?username=SHYAM-MD&show_icons=true&theme=dark&border_color=00ffff&title_color=00ffff&icon_color=00ffff" width="400"/>
  </a>
</div>
<!-- Glowing Header -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>

## 🤖 _SHYAM-MD STATUS_

```diff
+ Project Status: Active
! Version: V.5 Neon Edition
# License: BSD 3-Clause
```
<div align="center">
  <img src="https://capsule-render.vercel.app/api?type=wave&height=350&color=gradient&text=FREE%20SERVES%20🛜&animation=twinkling&fontAlign=36&fontAlignY=36&descAlign=62&reversal=false&textBg=false" width="100%">
</div>


<h3 align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=24&duration=6000&color=FFFFFF&background=000000&center=true&vCenter=true&width=600&lines=+SHYAM-MD+MD+QUALITY+EDITION+BY+MR+SHYAM-MD42;⚡+THE+FUTURE+OF+WHATSAPP+BOT+IS+HERE" alt="Footer Animation">
</h3>

<img src="https://i.imgur.com/dBaSKWF.gif" height="90" width="100%">

<!-- New Animated Contributors -->
<div style="margin-top:20px">

[![Contributors](https://readme-typing-svg.demolab.com?font=Fira+Code&size=16&duration=3000&pause=1000&color=58A6FF&background=00000000&center=true&vCenter=true&width=500&lines=THANKS+TO+ALL+CONTRIBUTORS+%F0%9F%99%8F;SPECIAL+THANKS+TO+OUR+STAR+SUPPORTERS+%E2%AD%90)](https://github.com/Dexsam07/SHYAM-MD-V2/graphs/contributors)

</div>

</div>

<p align="center"> <img src="https://i.imgur.com/LyHic3i.gif" /> </p> <h2 align="center">💫 Thanks To Our Loyal Followers</h2> <p align="center"> <a href="https://github.com/Dexsam07/SHYAM-MD-V2/stargazers"> <img src="http://reporoster.com/stars/dark/Dexsam07/SHYAM-MD-V2" alt="Stargazers Repo Roster For @Dexsam07/SHYAM-MD-V2"> </a> </p> <p align="center"> <a href="https://github.com/Dexsam07/SHYAM-MD-V2/network/members"> <img src="http://reporoster.com/forks/dark/Dexsam07/SHYAM-MD-V2" alt="Forkers Repo Roster For @Dexsam07/SHYAM-MD-V2"> </a> </p> 

<img src="https://i.imgur.com/dBaSKWF.gif" height="90" width="100%">

<h1> ℕ𝕆 𝕃𝕆𝕍𝔼 💔 ℕ𝕆 𝕊𝕋ℝ𝔼𝕊𝕊 <img src="https://media.giphy.com/media/VgCDAzcKvsR6OM0uWg/giphy.gif" width="45"> </h1>
